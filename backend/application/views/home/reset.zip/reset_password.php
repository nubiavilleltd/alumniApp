<?php defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('home/splash2');

echo'
    <section class="services-wrap">
        <div class="container">
            <div class="row">
                <div class="col-sm-5 hidden-sm wow animated fadeInLeft">
                <h3 class="heading">Welcome to Automator</h3>
                <!--bootstrap collapse-->
                <div class="panel-group" id="accordion">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="'.site_url('#collapseOne').'">
                                    <i class="fa fa-desktop"></i>What is Automator
                                </a>
                            </h4>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse in">
                            <div class="panel-body">
                              coming soon
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="'.site_url('#collapseTwo').'">
                                    <i class="fa fa-crop"></i> How Automator Works</a>
                            </h4>
                        </div>
                        <div id="collapseTwo" class="panel-collapse collapse">
                            <div class="panel-body">
                              coming soon
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="'.site_url('#collapseThree').'">
                                    <i class="fa fa-cogs"></i>Features List</a>
                            </h4>
                        </div>
                        <div id="collapseThree" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ui>
                                      <li>Robust Loyalty Rules Engine</i>
                                    <li>coming soon</i>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--collapse end-->
                </div>
                <div class="col-sm-7 col-xs-12 service-3-meta">
                    <h3 class="wow animated heading fadeInDownfadeInRight">Reset Password</h3>
                    <div class="services-box margin30 wow animated fadeInRight">
                        '.form_open('home/reset_password/' . $code,array('name'=>'loginform')).'  
                            <fieldset class="form-horizontal">
                                <div class="col-md-12">
                                    <div class="form-group"><label class="col-sm-5 control-label">New Password:</label>
                                        <div class="col-sm-7"><input name="new" id="new" type="password" class="form-control" 
                                        placeholder="Enter New Password"></div>
                                    </div>
                                </div>  
                                <div class="col-md-12">
                                    <div class="form-group"><label class="col-sm-5 control-label">Confirm Password:</label>
                                        <div class="col-sm-7"><input name="new_confirm" id="new_confirm" type="password" class="form-control" 
                                        placeholder="Enter Confirm Password"></div>
                                    </div>
                                </div>                                  
                                <div class="col-md-12 text-right">
                                    <button type="submit" name="login" class="btn btn-primary rounded btn-3d">Reset</button>
                                </div>                                    
                            </fieldset>
                            '.form_input($user_id).form_hidden($csrf).'
                        '.form_close().'       
                    </div><!--service box-->                    
                </div>
            </div>
        </div> 
    </section><!--services with the showcase mockups--> 
';
?>        